package com.example.submissiondicoding;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Figur> list = new ArrayList<>();
    private RecyclerView rvFigur;
    private String title = "Action Figure";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setActionBarTitle(title);

        rvFigur = findViewById(R.id.rv_figur);
        rvFigur.setHasFixedSize(true);

        list.addAll(FigurData.getListData());
        showRecyclerList();
    }

    private void setActionBarTitle(String title){
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(title);
        }
    }

    private void showRecyclerList() {
        rvFigur.setLayoutManager(new LinearLayoutManager(this));
        ListFigurAdapter listFigurAdapter = new ListFigurAdapter(list);
        rvFigur.setAdapter(listFigurAdapter);

        listFigurAdapter.setOnItemClickCallBack(new ListFigurAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Figur data) {
                Intent moveIntent = new Intent(MainActivity.this, DetailFigur.class);
                moveIntent.putExtra(DetailFigur.EXTRA_LINK,data.getPhoto());
                moveIntent.putExtra(DetailFigur.EXTRA_HARGA,data.getHarga());
                moveIntent.putExtra(DetailFigur.EXTRA_DETAIL,data.getDetail());
                moveIntent.putExtra(DetailFigur.EXTRA_CHARACTER,data.getCharacter());
                moveIntent.putExtra(DetailFigur.EXTRA_SERIES,data.getSeries());
                startActivity(moveIntent);
            }
        });
    }

    private void showRecyclerGrid() {
        rvFigur.setLayoutManager(new GridLayoutManager(this , 2));
        GridFigurAdapter gridFigurAdapter = new GridFigurAdapter(list);
        rvFigur.setAdapter(gridFigurAdapter);
    }

    //MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }

    private void setMode(int itemId) {
        switch (itemId){
            case R.id.action_about:
                Intent aboutIntent = new Intent(MainActivity.this , ActivityAbout.class);
                startActivity(aboutIntent);
                title = "Turah Tri";
                break;

            case R.id.action_list:
                showRecyclerList();
                title ="Action Figure";
                break;

            case R.id.action_grid:
                showRecyclerGrid();
                title = "Free Wallpaper";
                break;
        }
        setActionBarTitle(title);
    }

}
