package com.example.submissiondicoding;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class DetailFigur extends AppCompatActivity {
    public static final String EXTRA_LINK = "extra_link";
    public static final String EXTRA_HARGA = "extra_harga";
    public static final String EXTRA_DETAIL = "extra_detail";
    public static final String EXTRA_CHARACTER = "extra_character";
    public static final String EXTRA_SERIES = "extra_series";

    private String title = "Action Figure";

    ImageView imgPhoto;
    TextView tvHarga , tvDetail , tvCharacter , tvSeries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_figur);
        setActionBarTitle(title);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        String link = getIntent().getStringExtra(EXTRA_LINK);
        String harga = getIntent().getStringExtra(EXTRA_HARGA);
        String detail = getIntent().getStringExtra(EXTRA_DETAIL);
        String character = getIntent().getStringExtra(EXTRA_CHARACTER);
        String series = getIntent().getStringExtra(EXTRA_SERIES);
        setContentView(R.layout.activity_detail_figur);

        imgPhoto = findViewById(R.id.img_figur_photo);
        tvHarga = findViewById(R.id.tv_figur_harga);
        tvDetail = findViewById(R.id.tv_figur_detail);
        tvCharacter = findViewById(R.id.tv_figur_character);
        tvSeries = findViewById(R.id.tv_figur_series);

        Glide.with(this)
                .load(link)
                .into(imgPhoto);
        tvHarga.setText(harga);
        tvDetail.setText(detail);
        tvCharacter.setText(character);
        tvSeries.setText(series);

    }

    private void setActionBarTitle(String title){
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }
    private void setMode(int itemId) {
        switch (itemId){
            case R.id.action_favorit:
                Toast.makeText(this, "Favorite ",Toast.LENGTH_SHORT).show();
                return;
        }
    }
}
