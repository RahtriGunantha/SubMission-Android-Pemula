package com.example.submissiondicoding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class GridFigurAdapter extends RecyclerView.Adapter<GridFigurAdapter.GridViewHolder> {
    private ArrayList<Figur> listFigur;

    public GridFigurAdapter(ArrayList<Figur> list) {
        this.listFigur = list;
    }

    @NonNull
    @Override
    public GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_grid_figur, viewGroup , false);
        return new GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final GridViewHolder holder, int position) {
        Glide.with(holder.itemView.getContext())
                .load(listFigur.get(position).getImage())
                .apply(new RequestOptions().override(350 , 350))
                .into(holder.imgImage);
    }

    @Override
    public int getItemCount() {
        return listFigur.size();
    }

     class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imgImage;

         GridViewHolder(@NonNull View itemView) {
            super(itemView);
            imgImage = itemView.findViewById(R.id.img_item_images);
        }
    }
}
