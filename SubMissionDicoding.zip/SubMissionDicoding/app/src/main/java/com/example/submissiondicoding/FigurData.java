package com.example.submissiondicoding;

import java.util.ArrayList;

public class FigurData {
    private static String[] figurNames = {
            "Altria Pendragon",
            "Asuna Yuuki",
            "Chino Kafuu",
            "Hatsune Miku",
            "Kurumi Tokisaki",
            "Okita Souji",
            "Saber",
            "Yae Sakura",
            "Mythra",
            "Purple Heart"
    };

    private static String[] figurDatas = {
            "PVC Figure 1/8 Lancer / Altria Pendragon",
            "PVC Figure 1/7 Asuna Yuuki [Starry Night]",
            "PVC Figure 1/7 Chino Kafuu - Santa Version",
            "[Exclusive Sale] PVC Figure 1/8 Hatsune Miku - The First Dream Version",
            "PVC Figure 1/7 Kurumi Tokisaki - Alluring Kimono Version",
            "PVC Figure 1/7 Alter Ego / Okita Souji (Alter) - Absolute Blade : Endless Three Stage",
            "PVC Figure 1/7 Sabber Alter - Kimono Version",
            "PVC Figure 1/8 Yae Sakura - Chinesee Dress Version",
            "[Limited Distribution] PVC Figure 1/7 Mythra(Re-relase)",
            "PVC Figure 1/7 Purple Heart Lilac COOL"
    };

    private static String[] figurPhotos = {
            "https://cdn.kyou.id/items/48386-pvc-figure-18-lancer-altria-pendragon.jpg",
            "https://cdn.kyou.id/items/43213-pvc-figure-17-asuna-starry-night.jpg",
            "https://cdn.kyou.id/items/56222-pvc-figure-17-chino-santa-ver.jpg",
            "https://cdn.kyou.id/items/57927-exclusive-sale-pvc-figure-18-hatsune-miku-the-first-dream-ver.jpg",
            "https://cdn.kyou.id/items/35479-pvc-figure-17-kurumi-tokisaki-alluring-kimono-ver.jpg",
            "https://cdn.kyou.id/items/58056-pvc-figure-17-alter-ego-okita-souji-alter-x000d-absolute-blade-endless-three-stage.jpg",
            "https://cdn.kyou.id/items/55736-pvc-figure-17-saber-alter-kimono-ver.jpg",
            "https://cdn.kyou.id/items/55408-pvc-figure-18-yae-sakura-chinese-dress-ver.jpg",
            "https://cdn.kyou.id/items/53119-limited-distribution-pvc-figure-17-mythra-re-release.jpg",
            "https://cdn.kyou.id/items/48374-pvc-figure-17-purple-heart-lilac-cool.jpg"
    };

    private static String[] figurImages = {
            "https://image.winudf.com/v2/image/Y29tLmFuZHJvbW8uZGV2NjYwNjE0LmFwcDY5ODg1MF9zY3JlZW5fMV8xNTExMTkxMzc1XzA0MA/screen-1.jpg?fakeurl=1&type=.jpg",
            "https://i.pinimg.com/564x/b2/e6/2e/b2e62e3489835f375c56cd1d059877b3.jpg",
            "https://i.pinimg.com/originals/7a/e7/43/7ae743cee60c2214e2843b212692c966.jpg",
            "https://i.pinimg.com/originals/06/56/e9/0656e918d80b194d49f51dd28f339965.jpg",
            "https://i.pinimg.com/originals/d5/03/11/d5031139f91565d62cabf730d9742710.jpg",
            "https://i.pinimg.com/originals/d3/83/47/d383476303f77c50a332b47254ec409d.png",
            "https://i.pinimg.com/originals/0a/cd/a7/0acda7804ea60956277860b2247bda26.png",
            "https://i.pinimg.com/736x/8f/a4/91/8fa491c2ad52c273af815459028a7754.jpg",
            "https://i.pinimg.com/736x/8c/57/15/8c5715a0f0b34c97e9cf6385cab7c226.jpg",
            "https://i.pinimg.com/originals/dd/bc/cb/ddbccb58b21b4c60050f4fab66276128.jpg"
    };
    private static String[] figurHarga = {
            "IDR 3,900,000",
            "IDR 2,200,000",
            "IDR 2,590,000",
            "IDR 3,000,000",
            "IDR 2,830,000",
            "IDR 3,220,000",
            "IDR 3,690,000",
            "IDR 2,950,000",
            "IDR 4,250,000",
            "IDR 3,780,000"
    };

    private static String[] figurDetail = {
            "\"Holy lance, unleash your power!\"\n" +
                    "From the popular smartphone game \"Fate/Grand Order\" comes an impressive 1/8th scale figure of the Lancer servant, Altria Pendragon, based on her appearance in her third ascension! " +
                    "She is posed riding her beloved steed Dun Stallion in a heroic and mature pose that captures her as if just before making use of her powerful Noble Phantasm.\n" +
                    "\n" +
                    "The crimson cape that billows behind her and the deep blue outfit that shows off her impressive curves have all been sculpted in intricate detail, " +
                    "and the impressive armor on both the horse and Altria herself gleam with silver beauty. " +
                    "In her hand she holds the holy lance, Rhongomyniad, which makes use of translucent parts for a truly magnificent appearance. " +
                    "Be sure to add her to your side and experience the mighty Lancer and her trusty steed right by your side!",

            "\"Let's go see a meteor shower there someday.\"\n" +
                    "From \"Sword Art Online\" comes Asuna [Starry night]! She has been recreated in her outfit from Ordinal Scale. Her simple standing appearance, " +
                    "flowing long hair and elegant figure have all been meticulously captured. The shades of red throughout the figure " +
                    "have been painted to clearly portray lighting and shadows throughout. The engagement ring she received from Kirito has also been faithfully recreated. " +
                    "Be sure to add her to your collection!",

            "Merry Christmas! Presenting Chino in a Santa outfit!\n" +
                    "From \"Is the Order a Rabbit??\" comes a scale figure of Chino in a Santa outfit. " +
                    "Chino has been recreated with a cute embarrassed expression, " +
                    "stuck in a large present box while delivering presents. She comes with Tippy too, so enjoy displaying them together!",

            "Just walking together with you is pure happiness.\n" +
                    "From the first album created with Hatsune Miku V4 CHINESE, \"The First Dream\" " +
                    "comes a scale figure of Hatsune Miku based on the album's jacket illustration. Her cute and delicate " +
                    "appearance has been faithfully recreated in figure form. Her flowing twintails and soft, " +
                    "frilly skirt have been carefully sculpted, making for a charming appearance from any angle. " +
                    "The figure features finely detailed paintwork in order to accurately recreate the original illustration in figure form. " +
                    "Be sure to add her to your collection!",

            "\"Ufufu... this kimono looks good on me, don't you think?\"\n" +
                    "From KADOKAWA's Fantasia Bunko Editorial Department's light novel series \"Date A Live\" comes a 1/7th scale figure of heroine Kurumi Tokisaki! " +
                    "She's been recreated wearing a beautiful haregi based on her appearance on the cover of Date A Live Magazine, as illustrated by Tsunako. " +
                    "Kurumi's alluring beauty is on full display, with a boldly low collar and a kimono that shows off her impressive curves.\n" +
                    "\n" +
                    "The pattern of the kimono has also been faithfully recreated, supervised by Tsunako in order to recreate even the back of the kimono, " +
                    "unseen in the original illustration, in outstanding detail. Be sure to add her to your collection!",

            "Immeasurable, Unhindered, Unbound. The three beams weave together into Eternity—\n" +
                    "From the popular smartphone game \"Fate/Grand Order\" comes a scale figure of the Alter Ego class servant and Counter Guardian Okita Souji (Alter) in her Third Ascension appearance. " +
                    "She is equipped with her pitch-black blade Purgatory and has been captured in the very moment she is preparing to unleash her Noble Phantasm \"Absolute Blade: Endless Three Stage\".\n" +
                    "\n" +
                    "Her decisive, dignified expression, flowing pale pink hair and all of her armor and equipment have been recreated and carefully painted to preserve the appearance of differing textures in each area. " +
                    "Be sure to add her to your collection!",

            "Takashi Takeuchi's illustration of Saber Alter in a kimono is now a scale figure!\n" +
                    "From the anime movie series \"Fate/stay night: Heaven's Feel\" comes a 1/7th scale figure of Saber Alter! Takashi Takeuchi's illustration of Saber Alter in a gorgeous kimono originally made for Newtype magazine has been faithfully recreated by sculptor Nobuta (REVOLVE).\n" +
                    "\n" +
                    "Everything from her delicate expression to the bare skin peeking between the gaps of her elegant kimono has been carefully preserved in figure form. " +
                    "Her hair decorations, kanzashi and obi belt have all been captured with particular attention-to-detail. " +
                    "Be sure to add her to your collection!",

            "Details Here comes the miko \"Yae Sakura\" from miHoYo's popular smartphone game \"Honkai Impact 3rd\"!\n" +
                    "This figure is made by APEX's skillful sculptors according to the official illustration!\n" +
                    "Under the moonlight through window, Yae Sakura appears in a sexy China dress and sitting on a branch of cherry blossom tree.\n" +
                    "This figure comes with 3 types of alternative background boards. " +
                    "You can customize its background to create your favorite scene.",

            "A highly detailed figure of the other form of the legendary Blade!\n" +
                    "From the Nintendo Switch game \"Xenoblade Chronicles 2\" comes a 1/7th scale figure of Mythra, " +
                    "the alternate form of the legendary blade Pyra! The highly detailed original design by character designer Masatsugu Saito has been faithfully converted into a figure to capture Mythra's powerful yet beautiful appearance for fans to enjoy by their side! " +
                    "She is designed to be displayed together with the previously announced figure of Pyra - display them together and have their swords crossing for an epic joint pose!",

            "Purple Heart's new design featuring the Processor Unit Lilac COOL!\n" +
                    "From the new OVA \"Hyperdimension Neptunia: Nep's Summer Vacation\" comes a 1/7th scale figure of Purple Heart's new design featuring the Processor Unit Lilac COOL. " +
                    "The figure is based on an illustration by the original character designer Tsunako. " +
                    "Purple Heart is equipped with her great sword and Purple Sister's M.P.B.L.! Be sure to add her to your collection!"
    };

    private static String[] figurCharacter = {
            "Altria Pendragon",
            "Asuna Yuuki",
            "Chino Kafuu",
            "Hatsune Miku",
            "Kurumi Tokisaki",
            "Okita Souji",
            "Saber",
            "Yae Sakura",
            "Mythra",
            "Purple Heart"
    };

    private static String[] figurSeries = {
            "Fate Series",
            "Sword Art Online",
            "Gochuumon Wa Usagi Desu Ka ?",
            "Vocaloid",
            "Date A Live",
            "Fate Series",
            "Fate Series",
            "Honkai Impact 3",
            "Xenoblade Chronicles 2",
            "Hyperdimension Neptunia"
    };



    static ArrayList<Figur> getListData(){
        ArrayList<Figur> list = new ArrayList<>();
        for (int position = 0; position < figurNames.length; position++){
            Figur figur = new Figur();
            figur.setName(figurNames[position]);
            figur.setData(figurDatas[position]);
            figur.setPhoto(figurPhotos[position]);
            figur.setImage(figurImages[position]);
            figur.setHarga(figurHarga[position]);
            figur.setDetail(figurDetail[position]);
            figur.setCharacter(figurCharacter[position]);
            figur.setSeries(figurSeries[position]);

            list.add(figur);
        }
        return list;
    }
}
