package com.example.submissiondicoding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListFigurAdapter extends RecyclerView.Adapter<ListFigurAdapter.ListViewHolder> {
    private ArrayList<Figur> listFigur;

    public ListFigurAdapter(ArrayList<Figur> list){
        this.listFigur = list;
    }

    private OnItemClickCallback onItemClickCallBack;
    public void setOnItemClickCallBack(OnItemClickCallback onItemClickCallBack){
        this.onItemClickCallBack = onItemClickCallBack;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_figur, viewGroup, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
    Figur figur = listFigur.get(position);
        Glide.with(holder.itemView.getContext())
                .load(figur.getPhoto())
                .apply(new RequestOptions().override(55 , 55 ))
                .into(holder.imgPhoto);
        holder.tvName.setText(figur.getName());
        holder.tvData.setText(figur.getData());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallBack.onItemClicked(listFigur.get(holder.getAdapterPosition()));
            }
        });

    }

    @Override
    public int getItemCount() {
        return listFigur.size();
    }

     class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvName , tvData;

         ListViewHolder(@NonNull View itemView) {
            super(itemView);

            imgPhoto = itemView.findViewById(R.id.img_figur_photo);
            tvName = itemView.findViewById(R.id.tv_figur_name);
            tvData = itemView.findViewById(R.id.tv_figur_data);
        }
    }
    public interface OnItemClickCallback{
        void onItemClicked(Figur data);
    }
}
